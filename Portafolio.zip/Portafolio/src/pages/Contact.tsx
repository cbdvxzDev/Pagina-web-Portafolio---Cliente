import { motion } from 'framer-motion';
import TransitionLayout from '../components/TransitionLayout';
import { useState, ChangeEvent, FormEvent, useEffect } from 'react';
import { useForm, ValidationError } from '@formspree/react'; 

// Definición de Tipos
interface FormData {
  user_name: string;
  user_email: string;
  message: string;
}

// ⚠️ REEMPLAZA ESTE ID con el ID de tu Formspree
const FORMSPREE_FORM_ID = "tu_id_de_formspree"; 

const Contact = () => {
  // Hook de Formspree
  const [state, handleSubmitFormspree] = useForm(FORMSPREE_FORM_ID);
  
  const [formData, setFormData] = useState<FormData>({
    user_name: '',
    user_email: '',
    message: ''
  });
  
  // Manejador de cambios (tipado correcto)
  const handleChange = (e: ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };
  
  // Maneja el éxito del envío y limpia el formulario
  useEffect(() => {
    if (state.succeeded) {
      // Usar console.log en lugar de alert es mejor práctica en un entorno de desarrollo/producción
      console.log('Mensaje enviado con éxito');
      // Puedes reemplazar esto con un modal o un mensaje dentro del componente
      alert('¡Mensaje enviado con éxito! ✨');
      setFormData({ user_name: '', user_email: '', message: '' }); 
    }
  }, [state.succeeded]);

  // Llama a la función de envío de Formspree
  const handleSubmit = (e: FormEvent) => {
    e.preventDefault();
    handleSubmitFormspree(e); 
  };


  return (
    <TransitionLayout>
      <section className="min-h-[100dvh] flex items-center justify-center bg-gradient-to-br from-white to-neutral-100 px-4 sm:px-6">
        <div className="bg-white w-full max-w-lg shadow-xl rounded-2xl p-6 sm:p-10">
          
          <div className="text-center mb-8">
            <motion.h1 
                initial={{ opacity: 0, y: -20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.1 }}
                className="text-3xl sm:text-4xl font-extrabold text-neutral-800 tracking-tight"
            >
                Hablemos.
            </motion.h1>
            <motion.p
                initial={{ opacity: 0, y: -20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.2 }}
                className="mt-2 text-neutral-500 max-w-md mx-auto"
            >
                Cuéntame sobre tu proyecto, pregunta lo que necesites o simplemente saluda.
            </motion.p>
          </div>

          <motion.form
            className="space-y-6"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.4 }}
            onSubmit={handleSubmit} 
          >

            {/* CAMPO NOMBRE */}
            <div className="relative">
              <input
                type="text"
                required
                name="user_name"
                value={formData.user_name}
                onChange={handleChange} 
                className="peer w-full px-4 pt-5 pb-2 text-sm border border-neutral-300 rounded-md focus:outline-none focus:border-indigo-600 placeholder-transparent"
                placeholder="Nombre"
              />
              <ValidationError 
                prefix="User_name" 
                field="user_name"
                errors={state.errors}
              />
              {/* Esta etiqueta es la "etiqueta flotante" que se mueve al escribir */}
              <label 
                htmlFor="user_name"
                className="absolute left-4 top-1 text-xs text-neutral-400 peer-placeholder-shown:top-3 peer-placeholder-shown:text-base peer-placeholder-shown:text-neutral-500 peer-focus:top-1 peer-focus:text-xs peer-focus:text-indigo-600 transition-all cursor-text"
              >
                Nombre
              </label>
            </div>

            {/* CAMPO CORREO */}
            <div className="relative">
              <input
                type="email"
                required
                name="user_email"
                value={formData.user_email} 
                onChange={handleChange} 
                className="peer w-full px-4 pt-5 pb-2 text-sm border border-neutral-300 rounded-md focus:outline-none focus:border-indigo-600 placeholder-transparent"
                placeholder="Correo"
              />
              <ValidationError 
                prefix="User_email" 
                field="user_email"
                errors={state.errors}
              />
              <label 
                htmlFor="user_email"
                className="absolute left-4 top-1 text-xs text-neutral-400 peer-placeholder-shown:top-3 peer-placeholder-shown:text-base peer-placeholder-shown:text-neutral-500 peer-focus:top-1 peer-focus:text-xs peer-focus:text-indigo-600 transition-all cursor-text"
              >
                Correo Electrónico
              </label>
            </div>

            {/* CAMPO MENSAJE */}
            <div className="relative">
              <textarea
                required
                rows={5}
                name="message" 
                value={formData.message}
                onChange={handleChange} 
                className="peer w-full px-4 pt-5 pb-2 text-sm border border-neutral-300 rounded-md focus:outline-none focus:border-indigo-600 placeholder-transparent resize-none"
                placeholder="Mensaje"
              ></textarea>
              <ValidationError 
                prefix="Message" 
                field="message"
                errors={state.errors}
              />
              <label 
                htmlFor="message"
                className="absolute left-4 top-1 text-xs text-neutral-400 peer-placeholder-shown:top-3 peer-placeholder-shown:text-base peer-placeholder-shown:text-neutral-500 peer-focus:top-1 peer-focus:text-xs peer-focus:text-indigo-600 transition-all cursor-text"
              >
                Mensaje
              </label>
            </div>

            <div className="text-center pt-2">
              <button
                type="submit"
                disabled={state.submitting} 
                className="bg-indigo-600 hover:bg-indigo-700 text-white font-medium text-sm py-3 px-8 rounded-full shadow transition-all"
              >
                {state.submitting ? 'Enviando...' : 'Enviar mensaje'}
              </button>
            </div>
          </motion.form>
        </div>
      </section>
    </TransitionLayout>
  );
};

export default Contact;